
@foreach($order->get_products as $product)

<h3> {{$product->name}} </h3>
<p>{{$product->price}}руб</p>
<p>{{$product->count}}</p>
<form action="{{route('basket-remove',$product->id)}}" method="post">
	@csrf
<button type="submit">-</button>
</form>
<form action="{{route('basket-add',$product->id)}}" method="post">
	@csrf
<button type="submit">+</button>
</form>
<a href="{{route('product',[$product->category->code , $product->id])}}">check</a>


@endforeach
<hr>
<form>
    @csrf
     <button>Confirm order</button>
</form>
<p>Common price: руб.</p>