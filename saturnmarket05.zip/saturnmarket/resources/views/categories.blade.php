<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
		@foreach($categories as $category)
			 <a href="/{{$category->code}}">{{$category->name}}</a>
		@endforeach

		
</body>
</html>