<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
<div> 
	
	@foreach($category as $product)
		<p>{{$product->name}}</p> 
	@endforeach

</div>
</body>
</html>