<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use Illuminate\Support\Facades\DB;

class BasketController extends Controller
{
     public function basket()
    {
        $orderId = session('orderId');
        //dd($orderId);
        if(!is_null($orderId)){
            $order = Order::findOrFail($orderId);
        }
        return view('basket' , compact('order'));
    }

    public function basketPlace()
    {

        return view('basket');
    }

    public function basketAdd($productId)
    {
        $orderId = session('orderId');
        if(is_null($orderId)){
            $orderId = Order::create()->id;
            session(['orderId'=>$orderId]);

        }else{
            $order = Order::find($orderId);
        }
        //increase object 
        if($order->get_products->contains($productId)){
          
          //$pivotRow = $order->get_products()->where('product_id', $productId)->first()->pivot;
          //$object_update = DB::table('order_product')->where('product_id',$productId)->first();
          //$object_update->count += 1 ;
          $object_update = DB::table('order_product')->where('product_id',$productId)->first();
        $amount_of_goods = $object_update->count;
        $amount_of_goods++;
        DB::table('order_product')->where('product_id', $productId)->update(['count' => $amount_of_goods]);
        dd($object_update);
        
        }else{
            $order->get_products()->attach($productId);
        }
        
        return redirect()->route("basket");
    }

    public function basketRemove($productId)
    {   
        $orderId = session('orderId'); 
        if (is_null('orderId')){
            return view('basket' , compact('order'));
        }
        $order = Order::find($orderId);
        $order->get_products()->detach($productId);
        return redirect()->route('basket');
    }
}
