<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
	<div>
<h3> <?php echo e($product->name); ?> </h3>
<p><?php echo e($product->price); ?>руб</p>
<p><?php echo e($product->category->name); ?></p>
<form action="<?php echo e(route('basket-add',$product->id)); ?>" method="post">
	<?php echo csrf_field(); ?>
<button type="submit">В корзину</button>
</form>
</div>
</body>
</html><?php /**PATH D:\SaturnMarket\saturnmarket\resources\views/product.blade.php ENDPATH**/ ?>