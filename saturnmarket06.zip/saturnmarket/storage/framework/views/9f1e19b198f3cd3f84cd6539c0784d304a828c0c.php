
<?php $__currentLoopData = $order->get_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h3> <?php echo e($product->name); ?> </h3>
<p><?php echo e($product->price); ?>руб</p>
<p><?php echo e($product->pivot->count); ?></p>
<p><?php echo e($product->get_price_for_count()); ?></p>
<form action="<?php echo e(route('basket-remove',$product->id)); ?>" method="post">
	<?php echo csrf_field(); ?>
<button type="submit">-</button>
</form>
<form action="<?php echo e(route('basket-add',$product->id)); ?>" method="post">
	<?php echo csrf_field(); ?>
<button type="submit">+</button>
</form>
<a href="<?php echo e(route('product',[$product->category->code , $product->id])); ?>">check</a>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<hr>
<p>Common price:<?php echo e($order->get_total_price()); ?> руб.</p>
<form>
    <?php echo csrf_field(); ?>
     <button>Confirm order</button>
</form>
<?php /**PATH D:\SaturnMarket\saturnmarket\resources\views/basket.blade.php ENDPATH**/ ?>