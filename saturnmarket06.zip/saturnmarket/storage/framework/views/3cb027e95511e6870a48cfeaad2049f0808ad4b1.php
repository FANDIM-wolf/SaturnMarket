<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <a href="/<?php echo e($category->code); ?>"><?php echo e($category->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		
</body>
</html><?php /**PATH D:\SaturnMarket\saturnmarket\resources\views/categories.blade.php ENDPATH**/ ?>