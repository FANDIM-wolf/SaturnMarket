<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
<div> 
	
	<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<p><?php echo e($product->name); ?></p> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</body>
</html><?php /**PATH D:\SaturnMarket\saturnmarket\resources\views/category.blade.php ENDPATH**/ ?>