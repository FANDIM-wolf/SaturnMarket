
@foreach($order->get_products as $product)

<h3> {{$product->name}} </h3>
<p>{{$product->price}}руб</p>
<p>{{$product->pivot->count}}</p>
<p>{{$product->get_price_for_count()}}</p>
<form action="{{route('basket-remove',$product->id)}}" method="post">
	@csrf
<button type="submit">-</button>
</form>
<form action="{{route('basket-add',$product->id)}}" method="post">
	@csrf
<button type="submit">+</button>
</form>
<a href="{{route('product',[$product->category->code , $product->id])}}">check</a>


@endforeach
<hr>
<p>Common price:{{$order->get_total_price()}} руб.</p>
<form>
    @csrf
     <button>Confirm order</button>
</form>
