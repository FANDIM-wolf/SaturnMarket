<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SaturnMarket</title>
</head>
<body>
	<div>
			
	</div>
	@foreach($goods as $product)
		<div>
<h3> {{$product->name}} </h3>
<p>{{$product->price}}руб</p>
<p>{{$product->category->name}}</p>
<form action="{{route('basket-add',$product->id)}}" method="post">
	@csrf
<button type="submit">В корзину</button>
</form>
</div>
	@endforeach
</body>
</html>