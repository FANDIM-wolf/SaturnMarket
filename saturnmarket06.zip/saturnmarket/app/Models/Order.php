<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public function get_products(){
        return $this->belongsToMany(Product::class)->withPivot('count')->withTimestamps( );
    }


    public function get_total_price(){
        $total_price = 0;
        foreach($this->get_products as $product){
            $total_price += $product->get_price_for_count();
        }

        return $total_price;
    }
    

}
