<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use Illuminate\Support\Facades\DB;

class BasketController extends Controller
{
     public function basket()
    {
        // it will contains  price , name 
        //$array_of_goods = array();

        $orderId = session('orderId');
        //dd($orderId);
        if(!is_null($orderId)){
            $order = Order::findOrFail($orderId);
            $products = DB::table('order_product')->where('order_id',$orderId)->get();
            /*
            $products = DB::table('order_product')->where('order_id',$orderId)->get();
            for ($i =0 ; $i<count($products); $i++){
                $array_of_goods[$i] = DB::table('products')->where('id',$products[$i]->product_id)->first(); 
                //dd($array_of_goods);
            }
            */
        }
         
         //dd($products);
         return view('basket' , ['order' => $order]);
        //return view('basket' , compact('order'));
    }

    public function basketPlace()
    {

        return view('basket');
    }

    public function basketAdd($productId)
    {
        $order;
        $orderId = session('orderId');
        if(is_null($orderId)){
            $orderId = Order::create()->id;
            session(['orderId'=>$orderId]);

        }else{
            $order = Order::find($orderId);
        }
        //increase object 
        if($order->get_products->contains($productId)){
          
          //$pivotRow = $order->get_products()->where('product_id', $productId)->first()->pivot;
          //$object_update = DB::table('order_product')->where('product_id',$productId)->first();
          //$object_update->count += 1 ;
        $object_update = DB::table('order_product')->where('product_id',$productId)->first();
        $amount_of_goods = $object_update->count;
        $amount_of_goods++;
        DB::table('order_product')->where('product_id', $productId)->update(['count' => $amount_of_goods]);
        //dd($object_update);
        
        }else{
            $order->get_products()->attach($productId);
        }
        
        return redirect()->route("basket");
    }

    public function basketRemove($productId)
    {   
        $orderId = session('orderId'); 
        if (is_null('orderId')){
            return view('basket' , compact('order'));
        }
        $order = Order::find($orderId);
        //$order->get_products()->detach($productId);

        //decrease object 
        if($order->get_products->contains($productId)){
          
          //$pivotRow = $order->get_products()->where('product_id', $productId)->first()->pivot;
          //$object_update = DB::table('order_product')->where('product_id',$productId)->first();
          //$object_update->count += 1 ;
        $object_update = DB::table('order_product')->where('product_id',$productId)->first();
        $amount_of_goods = $object_update->count;
        if($amount_of_goods != 0){
            $amount_of_goods--;
        }
        if($amount_of_goods == 0 || $amount_of_goods <= 0){
           $order->get_products()->detach($productId);
           return redirect()->route('basket'); 
        }
        
        DB::table('order_product')->where('product_id', $productId)->update(['count' => $amount_of_goods]);
        //dd($object_update);
        
        }



        return redirect()->route('basket');
    }
}
