<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\Order;
use Stripe;
use Session;

class MainController extends Controller
{
    public function index(){
        $products = Product::get();
        
        return view('index' , ['goods' => $products]);
    }

    public function product($category,$product){

        //dd($product);
        $product = Product::where('id',$product)->first();
        //dd($product);

        return view('product' , ['product'=> $product]);
    }

    public function categories(){

        $categories = Category::get();

        return view('categories', ['categories'=> $categories]);
    }

    public function get_page_with_category($category){
        $CategoryObjects = Product::where('code' , $category)->get();
        
        return view('category' , ['category' => $CategoryObjects]);
    }



     /**
     * payment view
     */
    public function handleGet()
    {
        return view('home');
    }
  
    /**
     * handling payment with POST
     */
    public function handlePost(Request $request)
    {
        $orderId = session('orderId');
        $order = Order::find($orderId);

        $amount = $order->get_total_price();

        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        Stripe\Charge::create ([
                "amount" => $amount * 100,
                "currency" => "rub",
                "source" => $request->stripeToken,
                "description" => "Making test payment." 
        ]);
  
        Session::flash('success', 'Payment has been successfully processed.');
          
        return back();
    }

    
}
